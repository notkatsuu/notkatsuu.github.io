// src/App.js
import React from 'react';
import './App.css';
import NavBar from './components/NavBar';
import Hero from './components/Hero';
import ProjectList from './components/ProjectList';

function App() {
    return (
        <div className="App">
            <div className="sidebar">
                <Hero />
                <NavBar />
            </div>
            <div className="content">
                <div id="projects">
                    <h2>My Projects</h2>
                    <ProjectList />
                </div>
                {/* Add more content here */}
            </div>
        </div>
    );
}

export default App;