// src/components/ProjectList.js
import React, { useState } from 'react';
import ProjectCard from './ProjectCard';

const projects = [
    {
        name: 'kMusicPlayer',
        about: 'A web development project.',
        category: 'Software Development',
        languages: ['raylib', 'C'],
        image: '/images/demo.gif',
        link: 'https://example.com/project1'
    },
    {
        name: 'Project 2',
        about: 'A game development project.',
        category: 'Game Development',
        languages: ['C#', 'Unity'],
        image: '/images/project2.png',
        link: 'https://example.com/project2'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    },
    {
        name: 'Project 3',
        about: 'A web development project.',
        category: 'Web Development',
        languages: ['JavaScript', 'HTML', 'CSS'],
        image: '/images/project3.png',
        link: 'https://example.com/project3'
    }


    // Add more projects here
];

const categories = ['Web Development', 'Game Development', 'Software Development']; // Add more categories here
const languages = ['JavaScript', 'C#', 'HTML', 'CSS', 'Unity', 'raylib', 'C']; // Add more languages here

function ProjectList() {
    const [selectedCategories, setSelectedCategories] = useState([]);
    const [selectedLanguages, setSelectedLanguages] = useState([]);

    const handleCategoryChange = (e) => {
        const value = e.target.value;
        if (value !== "" && !selectedCategories.includes(value)) {
            setSelectedCategories([...selectedCategories, value]);
        }
    };

    const handleLanguageChange = (e) => {
        const value = e.target.value;
        if (value !== "" && !selectedLanguages.includes(value)) {
            setSelectedLanguages([...selectedLanguages, value]);
        }
    };

    const filteredProjects = projects.filter(project => {
        const categoryMatch = selectedCategories.length === 0 || selectedCategories.includes(project.category);
        const languageMatch = selectedLanguages.length === 0 || selectedLanguages.every(lang => project.languages.includes(lang));
        return categoryMatch && languageMatch;
    });

    const removeCategory = (category) => {
        setSelectedCategories(selectedCategories.filter((c) => c !== category));
    };

    const removeLanguage = (language) => {
        setSelectedLanguages(selectedLanguages.filter((l) => l !== language));
    };

    const availableCategories = categories.filter(category => !selectedCategories.includes(category));
    const availableLanguages = languages.filter(language => !selectedLanguages.includes(language));

    return (
        <div>
            <div className="filter-container">
                <select onChange={handleCategoryChange} className="filter" value="">
                    <option value="" disabled>Select a category</option>
                    {availableCategories.map((category, index) => (
                        <option key={index} value={category}>
                            {category}
                        </option>
                    ))}
                </select>
                <div className="filter-bubbles">
                    {selectedCategories.map((category, index) => (
                        <div key={index} className="filter-bubble" onClick={() => removeCategory(category)}>
                            {category}
                        </div>
                    ))}
                </div>
            </div>

            <div className="filter-container">
                <select onChange={handleLanguageChange} className="filter" value="">
                    <option value="" disabled>Select a language</option>
                    {availableLanguages.map((language, index) => (
                        <option key={index} value={language}>
                            {language}
                        </option>
                    ))}
                </select>
                <div className="filter-bubbles">
                    {selectedLanguages.map((language, index) => (
                        <div key={index} className="filter-bubble" onClick={() => removeLanguage(language)}>
                            {language}
                        </div>
                    ))}
                </div>
            </div>

            <div className="project-list">
                {filteredProjects.map((project, index) => (
                    <ProjectCard key={index} {...project} />
                ))}
            </div>
        </div>
    );
}

export default ProjectList;