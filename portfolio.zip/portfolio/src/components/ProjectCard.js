import React, { useState } from 'react';
import './ProjectCard.css';

function ProjectCard({ name, about, image, link }) {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div>
            <div className="project-card" onClick={() => setIsOpen(true)}>
                <img src={image} alt={name} className="project-image" />
                <h3>{name}</h3>
            </div>

            {isOpen && (
                <div className="modal">
                    <div className="modal-content">
                        <h3>{name}</h3>
                        <p>{about}</p>
                        <img src={image} alt={name} className="modal-image" />
                        <a href={link} target="_blank" rel="noopener noreferrer">View Project</a>
                        <button onClick={() => setIsOpen(false)}>Close</button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default ProjectCard;
